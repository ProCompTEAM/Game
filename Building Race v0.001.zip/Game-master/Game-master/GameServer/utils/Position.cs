﻿using System;

namespace GameServer.utils
{
	public class Position
	{
		public int X, Y;
		
		public Position(int Xpos, int Ypos)
		{
			X = Xpos;
			Y = Ypos;
		}
		
		public void Distance(Position pos)
		{
			//TODO ...
		}
	}
}
