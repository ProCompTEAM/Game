﻿using System;

namespace GameServer.ui
{
	public static class UI
	{
		
	}
}
