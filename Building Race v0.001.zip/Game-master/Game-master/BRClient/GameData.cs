﻿using System;

namespace BRClient
{
	public static class GameData
	{
		public static int WINDOW_WIDTH = 1280;
		public static int WINDOW_HEIGHT = 720;
		
		
	}
}
